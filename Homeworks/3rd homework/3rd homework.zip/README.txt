Patients:
alvaro@gmail.com - 1234
vegaromeroalvaro@gmail.com - 1234
patricia@outlook.com - 1234
djokovic@fri.si - 4321

Doctors:
doctor@gmail.com - 1234
healthlaura@outlook.com - 1234
popopo@gmail.com - 1234
