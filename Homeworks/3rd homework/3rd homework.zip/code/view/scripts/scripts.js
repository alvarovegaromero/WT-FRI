// Currently doing all the client side verifications in the files.
// Scripts are included in the files too